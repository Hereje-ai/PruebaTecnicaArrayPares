
public class Main {
    
    public static void main(String[] args) {
    String[] calcetines = {"azul", "rojo", "azul", "rojo"};

    // Crear un arreglo para almacenar el conteo de cada calcetín
    String[] colores = new String[calcetines.length];
    int[] conteos = new int[calcetines.length];
    int tamaño = 0;

    // Contar las apariciones de cada calcetín
    for (String calcetin : calcetines) {
        boolean encontrado = false;
        for (int i = 0; i < tamaño; i++) {
            if (colores[i].equals(calcetin)) {
                conteos[i]++;
                encontrado = true;
                break;
            }
        }
        if (!encontrado) {
            colores[tamaño] = calcetin;
            conteos[tamaño] = 1;
            tamaño++;
        }
    }

    // Encontrar y mostrar los calcetines sin par
    System.out.println("Calcetines sin par: " + tamaño);
    for (int i = 0; i < tamaño; i++) {
        if (conteos[i] % 2 != 0) {
            System.out.println(colores[i]);
        }
    }
}
}